#### 干货正在创造中 尽情期待，觉得内容可以的话  可以在右上方点击个小小的start

作者：[涂程](<https://github.com/interviewandroid/AndroidInterView>)

校对：[David](<https://github.com/interviewandroid/AndroidInterView>)

文章状态：编辑中

**关于项目**

> [AndroidInterView](<https://github.com/interviewandroid/AndroidInterView>)项目旨在通过提供一系列最新的Android高级面试题，最顶尖的行业干货。降低面试Android岗位的门槛，让更多的Android工程师理解Android系统，掌握Android系统。

**文章目录**



文章正文



> 本篇文章到这里就结束了，欢迎关注我们的AndroidInterView微信公众平台，AndroidInterView致力于分享Android系统源码的设计与实现相关文章，也欢迎开源爱好者参与到AndroidInterView项目中来。



##### 后续持续更新中，添加QQ群：4112676, 备注github

##### 加微信号，获取Android 2019年面试视频。发送"面试 "即可领取   另附企业内推，架构设计资料，相关视频资料

微信号

[![image](../img/img.jpg)](